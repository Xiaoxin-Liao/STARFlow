Run the following code:
pic=NPEA('example.jpg');
Then you can get the enhanced image.
figure imshow(pic);